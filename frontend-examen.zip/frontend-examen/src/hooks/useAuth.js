import { useContext, useState } from "react";
import { AuthContext } from "../context/AuthContext";
const url=import.meta.env.VITE_API_URL;

export const useAuth = () => {
const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("token") || null);
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  const {
    
    isAuthenticated,
    authError,
    setAuthError,
    login,
    
  } = context;

  const loginUser = async (userData) => {
   
    try {
      const response = await fetch(
        `${url}/api/auth/login`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(userData),
          
        }
      );
      if (!response.ok) {
        throw new Error("Error en el Login");
      }
      const data = await response.json();
      setUser(data.user);
      setToken(data.token);
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));
      login(data.user, data.token);
    } catch (error) {
      
      throw new Error("Error en el login", error);
    }
  };
  return {
    user,
    token,
    isAuthenticated,
    authError,
    setAuthError,
    loginUser,
  };
}