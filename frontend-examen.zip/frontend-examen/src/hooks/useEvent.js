import { useState } from "react";
const url=import.meta.env.VITE_API_URL;

export const useEvent = () => {
const [event, setEvent] = useState(null);
  

  const fetchEvents = async () => {
    try {
      const response = await fetch(`${url}/api/events`);
      if (!response.ok) {
        throw new Error("Error en el eventos");
      }
      const data = await response.json();
      console.log(data)
      setEvent(data.event);
      localStorage.setItem("event", JSON.stringify(data.user));
      
    } catch (error) {
      
      throw new Error("Error en el eventos", error);
    }
  };

  const CreateEvents = async (formData) => {
    try {
      const response = await fetch(`${url}/api/events/`, {
        
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(formData),
          
      });
      if (!response.ok) {
        throw new Error("Error en el eventos");
      }
      const data = await response.json();
      return data;
      
    } catch (error) {
      
      throw new Error("Error en el eventos", error);
    }
  };
  return {
    fetchEvents,
    event,
    CreateEvents
  }

}