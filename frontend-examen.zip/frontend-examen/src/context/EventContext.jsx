import { createContext, useState } from "react";

export const AuthContext = createContext(null);


export const AuthProvider = ({ children }) => {
   
    const [events, setevents] = useState([])
    

    
    return (
        <AuthProvider.Provider value={{}}>{children}</AuthProvider.Provider>
    )
};